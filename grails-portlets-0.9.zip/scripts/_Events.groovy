// Pacakging of portlet must be handled by portlet implementation
